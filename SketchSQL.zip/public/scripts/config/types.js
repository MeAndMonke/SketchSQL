export const typeOptions = ['INT', 'VARCHAR', 'TEXT', 'BOOLEAN', 'DATE', 'DATETIME', 'FLOAT', 'DOUBLE'];
