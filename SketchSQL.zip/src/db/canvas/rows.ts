import { Router } from 'express';
import type { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import pool from '../../db/db.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const router = Router();

router.get('/api/getRows', async (req: Request, res: Response) => {
    const nodeId = req.query.nodeId as string;
    try {
        const connection = await pool.getConnection();
        const [rows]: any = await connection.query(
            'SELECT * FROM RowEntries WHERE nodeID = ?',
            [ nodeId ]
        );
        connection.release();
        res.json({ rows: rows });
    } catch (error) {
        console.error('Database error details:', error);
        res.status(500).json({ message: 'Database error' });
    }
});

router.post('/api/saveRow', async (req: Request, res: Response) => {
    const { row } = req.body;
    try {
        const connection = await pool.getConnection();
        await connection.query(`UPDATE RowEntries
            SET rowIndex = ?,
            name = ?,
            type = ?,
            comment = ?,
            defaultValue = ?,
            indexType = ?,
            nullable = ?,
            autoIncrement = ?,
            isUnsigned = ?
            WHERE id = ?`,
            [ row.rowIndex, row.name, row.type, row.comment, row.defaultValue, row.indexType, row.nullable, row.autoIncrement, row.isUnsigned, row.id ]);
        connection.release();
        res.json({ message: 'Rows saved successfully' });
    } catch (error) {
        console.error('Database error details:', error);
        res.status(500).json({ message: 'Database error' });
    }
});

export default router;
